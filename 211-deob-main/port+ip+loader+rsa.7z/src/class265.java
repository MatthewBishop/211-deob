public interface class265 extends class267 {
}
