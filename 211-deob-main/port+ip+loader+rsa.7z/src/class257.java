public class class257 {

	static Decimator decimator;
}
