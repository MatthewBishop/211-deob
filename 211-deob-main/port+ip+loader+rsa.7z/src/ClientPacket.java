public class ClientPacket implements class278 {

	public static final ClientPacket field2466 = new ClientPacket(0, 0);

	public static final ClientPacket field2430 = new ClientPacket(1, 7);

	public static final ClientPacket field2534 = new ClientPacket(2, -1);

	public static final ClientPacket field2432 = new ClientPacket(3, 6);

	public static final ClientPacket field2433 = new ClientPacket(4, 7);

	static final ClientPacket field2477 = new ClientPacket(5, 7);

	public static final ClientPacket field2435 = new ClientPacket(6, -1);

	public static final ClientPacket field2436 = new ClientPacket(7, 3);

	public static final ClientPacket field2514 = new ClientPacket(8, 4);

	public static final ClientPacket field2445 = new ClientPacket(9, 3);

	public static final ClientPacket field2494 = new ClientPacket(10, 5);

	public static final ClientPacket field2440 = new ClientPacket(11, 3);

	public static final ClientPacket field2441 = new ClientPacket(12, 4);

	public static final ClientPacket field2442 = new ClientPacket(13, -1);

	public static final ClientPacket field2443 = new ClientPacket(14, -2);

	public static final ClientPacket field2528 = new ClientPacket(15, -1);

	public static final ClientPacket field2444 = new ClientPacket(16, 7);

	public static final ClientPacket field2437 = new ClientPacket(17, 11);

	public static final ClientPacket field2447 = new ClientPacket(18, 8);

	public static final ClientPacket field2519 = new ClientPacket(19, -1);

	public static final ClientPacket field2449 = new ClientPacket(20, 2);

	public static final ClientPacket field2434 = new ClientPacket(21, -1);

	public static final ClientPacket field2451 = new ClientPacket(22, 8);

	public static final ClientPacket field2452 = new ClientPacket(23, 7);

	public static final ClientPacket field2453 = new ClientPacket(24, -1);

	public static final ClientPacket field2509 = new ClientPacket(25, 8);

	public static final ClientPacket field2455 = new ClientPacket(26, -1);

	public static final ClientPacket field2456 = new ClientPacket(27, 16);

	public static final ClientPacket field2457 = new ClientPacket(28, -1);

	public static final ClientPacket field2531 = new ClientPacket(29, 4);

	public static final ClientPacket field2438 = new ClientPacket(30, 3);

	public static final ClientPacket field2460 = new ClientPacket(31, 2);

	public static final ClientPacket field2513 = new ClientPacket(32, 3);

	public static final ClientPacket field2501 = new ClientPacket(33, -1);

	public static final ClientPacket field2463 = new ClientPacket(34, -1);

	public static final ClientPacket field2464 = new ClientPacket(35, 4);

	public static final ClientPacket field2467 = new ClientPacket(36, 8);

	public static final ClientPacket field2450 = new ClientPacket(37, 3);

	public static final ClientPacket field2461 = new ClientPacket(38, 7);

	public static final ClientPacket field2468 = new ClientPacket(39, 1);

	public static final ClientPacket field2469 = new ClientPacket(40, 13);

	public static final ClientPacket field2470 = new ClientPacket(41, 7);

	public static final ClientPacket field2431 = new ClientPacket(42, -1);

	public static final ClientPacket field2530 = new ClientPacket(43, 8);

	public static final ClientPacket field2473 = new ClientPacket(44, 8);

	static final ClientPacket field2481 = new ClientPacket(45, -1);

	public static final ClientPacket field2496 = new ClientPacket(46, -1);

	public static final ClientPacket field2476 = new ClientPacket(47, 11);

	public static final ClientPacket field2439 = new ClientPacket(48, 10);

	public static final ClientPacket field2478 = new ClientPacket(49, 3);

	public static final ClientPacket field2479 = new ClientPacket(50, 3);

	public static final ClientPacket field2448 = new ClientPacket(51, 14);

	public static final ClientPacket field2459 = new ClientPacket(52, -1);

	public static final ClientPacket field2482 = new ClientPacket(53, -1);

	public static final ClientPacket field2483 = new ClientPacket(54, -1);

	public static final ClientPacket field2484 = new ClientPacket(55, 8);

	public static final ClientPacket field2485 = new ClientPacket(56, 15);

	public static final ClientPacket field2486 = new ClientPacket(57, 8);

	public static final ClientPacket field2487 = new ClientPacket(58, 16);

	public static final ClientPacket field2488 = new ClientPacket(59, 3);

	public static final ClientPacket field2489 = new ClientPacket(60, 11);

	public static final ClientPacket field2490 = new ClientPacket(61, -1);

	public static final ClientPacket field2491 = new ClientPacket(62, 8);

	public static final ClientPacket field2492 = new ClientPacket(63, 3);

	public static final ClientPacket field2493 = new ClientPacket(64, 8);

	public static final ClientPacket field2535 = new ClientPacket(65, 7);

	static final ClientPacket field2495 = new ClientPacket(66, -1);

	public static final ClientPacket field2446 = new ClientPacket(67, 7);

	public static final ClientPacket field2497 = new ClientPacket(68, 16);

	public static final ClientPacket field2498 = new ClientPacket(69, -2);

	public static final ClientPacket field2499 = new ClientPacket(70, 3);

	public static final ClientPacket field2500 = new ClientPacket(71, -1);

	public static final ClientPacket field2458 = new ClientPacket(72, 9);

	static final ClientPacket field2502 = new ClientPacket(73, 2);

	public static final ClientPacket field2516 = new ClientPacket(74, 4);

	public static final ClientPacket field2504 = new ClientPacket(75, 8);

	public static final ClientPacket field2505 = new ClientPacket(76, 8);

	static final ClientPacket field2454 = new ClientPacket(77, -1);

	public static final ClientPacket field2507 = new ClientPacket(78, 8);

	public static final ClientPacket field2508 = new ClientPacket(79, 0);

	public static final ClientPacket field2429 = new ClientPacket(80, 2);

	public static final ClientPacket field2510 = new ClientPacket(81, 8);

	public static final ClientPacket field2511 = new ClientPacket(82, 15);

	public static final ClientPacket field2512 = new ClientPacket(83, 9);

	public static final ClientPacket field2503 = new ClientPacket(84, 0);

	public static final ClientPacket field2518 = new ClientPacket(85, 8);

	public static final ClientPacket field2515 = new ClientPacket(86, 2);

	public static final ClientPacket field2529 = new ClientPacket(87, 6);

	public static final ClientPacket field2517 = new ClientPacket(88, 3);

	public static final ClientPacket field2462 = new ClientPacket(89, 8);

	public static final ClientPacket field2474 = new ClientPacket(90, 8);

	public static final ClientPacket field2520 = new ClientPacket(91, 8);

	public static final ClientPacket field2521 = new ClientPacket(92, 3);

	public static final ClientPacket field2522 = new ClientPacket(93, -2);

	public static final ClientPacket field2523 = new ClientPacket(94, 6);

	public static final ClientPacket field2524 = new ClientPacket(95, 15);

	public static final ClientPacket field2525 = new ClientPacket(96, 3);

	public static final ClientPacket field2526 = new ClientPacket(97, -1);

	public static final ClientPacket field2527 = new ClientPacket(98, 0);

	public static final ClientPacket field2532 = new ClientPacket(99, 22);

	public static final ClientPacket field2465 = new ClientPacket(100, 0);

	public static final ClientPacket field2475 = new ClientPacket(101, 7);

	public static final ClientPacket field2480 = new ClientPacket(102, 8);

	public static final ClientPacket field2506 = new ClientPacket(103, 8);

	public static final ClientPacket field2533 = new ClientPacket(104, 7);

	public static final ClientPacket field2471 = new ClientPacket(105, 15);

	public static final ClientPacket field2472 = new ClientPacket(106, -1);

	public static final ClientPacket field2536 = new ClientPacket(107, 11);

	final int id;

	final int length;

	ClientPacket(int var1, int var2) {
		this.id = var1;
		this.length = var2;
	}

	public static DbTableType getDbTableType(int var0) {
		DbTableType var1 = (DbTableType) DbTableType.DBTableType_cache.get((long) var0);
		if (var1 != null) {
			return var1;
		} else {
			byte[] var2 = DbTableType.field3990.takeFile(39, var0);
			var1 = new DbTableType();
			if (var2 != null) {
				var1.method2346(new Buffer(var2));
			}

			var1.method2348();
			DbTableType.DBTableType_cache.put(var1, (long) var0);
			return var1;
		}
	}

	public static synchronized byte[] ByteArrayPool_getArray(int var0) {
		return ByteArrayPool.ByteArrayPool_getArrayBool(var0, false);
	}

	static final void updateItemPile(int var0, int var1) {
		NodeDeque var2 = Client.groundItems[class103.Client_plane][var0][var1];
		if (var2 == null) {
			WorldMapAreaData.scene.removeGroundItemPile(class103.Client_plane, var0, var1);
		} else {
			long var3 = -99999999L;
			TileItem var5 = null;

			TileItem var6;
			for (var6 = (TileItem) var2.last(); var6 != null; var6 = (TileItem) var2.previous()) {
				ItemComposition var7 = TileItem.ItemDefinition_get(var6.id);
				long var8 = (long) var7.price;
				if (var7.isStackable == 1) {
					var8 *= var6.quantity < Integer.MAX_VALUE ? (long) (var6.quantity + 1) : (long) var6.quantity;
				}

				if (var8 > var3) {
					var3 = var8;
					var5 = var6;
				}
			}

			if (var5 == null) {
				WorldMapAreaData.scene.removeGroundItemPile(class103.Client_plane, var0, var1);
			} else {
				var2.addLast(var5);
				TileItem var12 = null;
				TileItem var11 = null;

				for (var6 = (TileItem) var2.last(); var6 != null; var6 = (TileItem) var2.previous()) {
					if (var5.id != var6.id) {
						if (var12 == null) {
							var12 = var6;
						}

						if (var6.id != var12.id && var11 == null) {
							var11 = var6;
						}
					}
				}

				long var9 = ItemLayer.calculateTag(var0, var1, 3, false, 0);
				WorldMapAreaData.scene
						.newGroundItemPile(
								class103.Client_plane, var0, var1, GrandExchangeOfferNameComparator
										.getTileHeight(var0 * 128 + 64, var1 * 128 + 64, class103.Client_plane),
								var5, var9, var12, var11);
			}
		}
	}

	static final void updateNpcs(boolean var0, PacketBuffer var1) {
		Client.field502 = 0;
		Client.field425 = 0;
		class17.method61(var1);

		int var2;
		int var3;
		int var7;
		int var8;
		int var9;
		int var10;
		int var11;
		int var23;
		while (true) {
			var2 = ServerPacket.field2674 ? 16 : 15;
			var3 = 1 << var2;
			if (var1.bitsRemaining(Client.packetWriter.serverPacketLength) < var2 + 12) {
				break;
			}

			int var4 = var1.readBits(var2);
			if (var4 == var3 - 1) {
				break;
			}

			boolean var5 = false;
			if (Client.npcs[var4] == null) {
				Client.npcs[var4] = new NPC();
				var5 = true;
			}

			NPC var20 = Client.npcs[var4];
			Client.npcIndices[++Client.npcCount - 1] = var4;
			var20.npcCycle = Client.cycle;
			if (ServerPacket.field2674) {
				var10 = Client.defaultRotations[var1.readBits(3)];
				if (var5) {
					var20.orientation = var20.rotation = var10;
				}

				if (var0) {
					var8 = var1.readBits(8);
					if (var8 > 127) {
						var8 -= 256;
					}
				} else {
					var8 = var1.readBits(5);
					if (var8 > 15) {
						var8 -= 32;
					}
				}

				var11 = var1.readBits(1);
				if (var11 == 1) {
					Client.field426[++Client.field425 - 1] = var4;
				}

				boolean var12 = var1.readBits(1) == 1;
				if (var12) {
					var1.readBits(32);
				}

				var7 = var1.readBits(1);
				if (var0) {
					var9 = var1.readBits(8);
					if (var9 > 127) {
						var9 -= 256;
					}
				} else {
					var9 = var1.readBits(5);
					if (var9 > 15) {
						var9 -= 32;
					}
				}

				var20.definition = class137.getNpcDefinition(var1.readBits(14));
			} else {
				if (var0) {
					var9 = var1.readBits(8);
					if (var9 > 127) {
						var9 -= 256;
					}
				} else {
					var9 = var1.readBits(5);
					if (var9 > 15) {
						var9 -= 32;
					}
				}

				var20.definition = class137.getNpcDefinition(var1.readBits(14));
				boolean var22 = var1.readBits(1) == 1;
				if (var22) {
					var1.readBits(32);
				}

				var11 = var1.readBits(1);
				if (var11 == 1) {
					Client.field426[++Client.field425 - 1] = var4;
				}

				var23 = Client.defaultRotations[var1.readBits(3)];
				if (var5) {
					var20.orientation = var20.rotation = var23;
				}

				if (var0) {
					var8 = var1.readBits(8);
					if (var8 > 127) {
						var8 -= 256;
					}
				} else {
					var8 = var1.readBits(5);
					if (var8 > 15) {
						var8 -= 32;
					}
				}

				var7 = var1.readBits(1);
			}

			WorldMapID.method1457(var20);
			if (var20.field1004 == 0) {
				var20.rotation = 0;
			}

			var20.method562(class387.localPlayer.pathX[0] + var8, class387.localPlayer.pathY[0] + var9, var7 == 1);
		}

		var1.exportIndex();

		for (var2 = 0; var2 < Client.field425; ++var2) {
			var3 = Client.field426[var2];
			NPC var14 = Client.npcs[var3];
			int var21 = var1.readUnsignedByte();
			int var6;
			if ((var21 & 2) != 0) {
				var6 = var1.readUnsignedByte();
				var21 += var6 << 8;
			}

			if ((var21 & 16384) != 0) {
				var6 = var1.readUnsignedByte();
				var21 += var6 << 16;
			}

			if ((var21 & 16) != 0) {
				var14.targetIndex = var1.readUnsignedShortLE();
				if (ServerPacket.field2674) {
					var14.targetIndex += var1.readUnsignedByteA() << 16;
					var6 = 16777215;
				} else {
					var6 = 65535;
				}

				if (var6 == var14.targetIndex) {
					var14.targetIndex = -1;
				}
			}

			if ((var21 & 64) != 0) {
				var6 = var1.readUnsignedShortLE();
				if (var6 == 65535) {
					var6 = -1;
				}

				var7 = var1.method2401();
				if (var6 == var14.sequence && var6 != -1) {
					var8 = class85.SequenceDefinition_get(var6).replyMode;
					if (var8 == 1) {
						var14.sequenceFrame = 0;
						var14.sequenceFrameCycle = 0;
						var14.sequenceDelay = var7;
						var14.currentSequenceFrameIndex = 0;
					}

					if (var8 == 2) {
						var14.currentSequenceFrameIndex = 0;
					}
				} else if (var6 == -1 || var14.sequence == -1
						|| class85.SequenceDefinition_get(var6).forcedPriority >= class85
								.SequenceDefinition_get(var14.sequence).forcedPriority) {
					var14.sequence = var6;
					var14.sequenceFrame = 0;
					var14.sequenceFrameCycle = 0;
					var14.sequenceDelay = var7;
					var14.currentSequenceFrameIndex = 0;
					var14.field1006 = var14.pathLength;
				}
			}

			if ((var21 & 4096) != 0) {
				var14.method559(var1.readUnsignedByte());
			}

			int[] var15;
			short[] var16;
			short[] var17;
			long var18;
			if ((var21 & '耀') != 0) {
				var6 = var1.readUnsignedByteA();
				if ((var6 & 1) == 1) {
					var14.method568();
				} else {
					var15 = null;
					if ((var6 & 2) == 2) {
						var8 = var1.readUnsignedByte();
						var15 = new int[var8];

						for (var9 = 0; var9 < var8; ++var9) {
							var10 = var1.readUnsignedByteS();
							var10 = var10 == 65535 ? -1 : var10;
							var15[var9] = var10;
						}
					}

					var16 = null;
					if ((var6 & 4) == 4) {
						var9 = 0;
						if (var14.definition.recolorTo != null) {
							var9 = var14.definition.recolorTo.length;
						}

						var16 = new short[var9];

						for (var10 = 0; var10 < var9; ++var10) {
							var16[var10] = (short) var1.readUnsignedShort();
						}
					}

					var17 = null;
					if ((var6 & 8) == 8) {
						var10 = 0;
						if (var14.definition.retextureTo != null) {
							var10 = var14.definition.retextureTo.length;
						}

						var17 = new short[var10];

						for (var11 = 0; var11 < var10; ++var11) {
							var17[var11] = (short) var1.readUnsignedShortLE();
						}
					}

					var18 = (long) (++NPC.field1053 - 1);
					var14.method570(new NewShit(var18, var15, var16, var17));
				}
			}

			if ((var21 & 256) != 0) {
				var14.exactMoveDeltaX1 = var1.method2442();
				var14.exactMoveDeltaY1 = var1.method2431();
				var14.exactMoveDeltaX2 = var1.method2404();
				var14.exactMoveDeltaY2 = var1.method2442();
				var14.exactMoveArrive1Cycle = var1.readUnsignedShort() + Client.cycle;
				var14.exactMoveArrive2Cycle = var1.readUnsignedShort() + Client.cycle;
				var14.exactMoveDirection = var1.readUnsignedByteS();
				var14.pathLength = 1;
				var14.field1006 = 0;
				var14.exactMoveDeltaX1 += var14.pathX[0];
				var14.exactMoveDeltaY1 += var14.pathY[0];
				var14.exactMoveDeltaX2 += var14.pathX[0];
				var14.exactMoveDeltaY2 += var14.pathY[0];
			}

			if ((var21 & 128) != 0) {
				var6 = var1.readUnsignedShortLE();
				var7 = var1.readUnsignedByteS();
				var14.instantTurn = var1.readUnsignedByte() == 1;
				var8 = var14.x - (var6 - ParamComposition.baseX - ParamComposition.baseX) * 64;
				var9 = var14.y - (var7 - Client.baseY - Client.baseY) * 64;
				if (var8 != 0 || var9 != 0) {
					var14.movingOrientation = (int) (Math.atan2((double) var8, (double) var9) * 325.949D) & 2047;
				}
			}

			if ((var21 & 2048) != 0) {
				var14.combatLevelChange = var1.readInt();
			}

			if ((var21 & 131072) != 0) {
				var6 = var1.readUnsignedByte();
				var15 = new int[8];
				var16 = new short[8];

				for (var9 = 0; var9 < 8; ++var9) {
					if ((var6 & 1 << var9) != 0) {
						var15[var9] = var1.method2419();
						var16[var9] = (short) var1.method2389();
					} else {
						var15[var9] = -1;
						var16[var9] = -1;
					}
				}

				var14.method557(var15, var16);
			}

			if ((var21 & 1024) != 0) {
				var14.method558(var1.readStringCp1252NullTerminated());
			}

			if ((var21 & 65536) != 0) {
				var6 = var1.method2417();
				var14.turnLeftSequence = (var6 & 1) != 0 ? var1.readUnsignedShortLEA()
						: var14.definition.turnLeftSequence * 1548038695 * -854123113;
				var14.turnRightSequence = (var6 & 2) != 0 ? var1.readUnsignedShortLEA()
						: var14.definition.turnRightSequence * -1404307261 * 165705707;
				var14.walkSequence = (var6 & 4) != 0 ? var1.readUnsignedShortLEA()
						: var14.definition.walkSequence * 813852611 * -1667350293;
				var14.walkBackSequence = (var6 & 8) != 0 ? var1.readUnsignedShortLE()
						: var14.definition.walkBackSequence * 125166595 * -1692211541;
				var14.walkLeftSequence = (var6 & 16) != 0 ? var1.readUnsignedShortLEA()
						: var14.definition.walkLeftSequence * 884354517 * -638999683;
				var14.walkRightSequence = (var6 & 32) != 0 ? var1.readUnsignedShortLEA()
						: var14.definition.walkRightSequence * 52307579 * -1977497421;
				var14.runSequence = (var6 & 64) != 0 ? var1.readUnsignedShort()
						: var14.definition.runSequence * -1499684449 * -42059169;
				var14.runBackSequence = (var6 & 128) != 0 ? var1.readUnsignedShort()
						: var14.definition.runBackSequence * -2144485029 * 1836877523;
				var14.runLeftSequence = (var6 & 256) != 0 ? var1.readUnsignedShortLE()
						: var14.definition.runLeftSequence * -1383865603 * -962409899;
				var14.runRightSequence = (var6 & 512) != 0 ? var1.readUnsignedShortLEA()
						: var14.definition.runRightSequence * 1572514813 * -1548940971;
				var14.crawlSequence = (var6 & 1024) != 0 ? var1.readUnsignedShortLE()
						: var14.definition.crawlSequence * -820400097 * 1529465823;
				var14.crawlBackSequence = (var6 & 2048) != 0 ? var1.readUnsignedShort()
						: var14.definition.crawlBackSequence * -1913284829 * -559656821;
				var14.crawlLeftSequence = (var6 & 4096) != 0 ? var1.readUnsignedByteS()
						: var14.definition.crawlLeftSequence * 253486965 * 307130589;
				var14.crawlRightSequence = (var6 & 8192) != 0 ? var1.readUnsignedShortLE()
						: var14.definition.crawlRightSequence * -2049517761 * -652699457;
				var14.idleSequence = (var6 & 16384) != 0 ? var1.readUnsignedShortLEA()
						: var14.definition.idleSequence * 1602286699 * 1686247491;
			}

			if ((var21 & 32) != 0) {
				var6 = var1.readUnsignedByte();
				if (var6 > 0) {
					for (var7 = 0; var7 < var6; ++var7) {
						var9 = -1;
						var10 = -1;
						var11 = -1;
						var8 = var1.readUShortSmart();
						if (var8 == 32767) {
							var8 = var1.readUShortSmart();
							var10 = var1.readUShortSmart();
							var9 = var1.readUShortSmart();
							var11 = var1.readUShortSmart();
						} else if (var8 != 32766) {
							var10 = var1.readUShortSmart();
						} else {
							var8 = -1;
						}

						var23 = var1.readUShortSmart();
						var14.addHitSplat(var8, var10, var9, var11, Client.cycle, var23);
					}
				}

				var7 = var1.readUnsignedByteA();
				if (var7 > 0) {
					for (var8 = 0; var8 < var7; ++var8) {
						var9 = var1.readUShortSmart();
						var10 = var1.readUShortSmart();
						if (var10 != 32767) {
							var11 = var1.readUShortSmart();
							var23 = var1.readUnsignedShortA();
							int var13 = var10 > 0 ? var1.readUnsignedShortA() : var23;
							var14.addHealthBar(var9, Client.cycle, var10, var11, var23, var13);
						} else {
							var14.removeHealthBar(var9);
						}
					}
				}
			}

			if ((var21 & 8) != 0) {
				var14.overheadText = var1.readStringCp1252NullTerminated();
				var14.overheadTextCyclesRemaining = 100;
			}

			if ((var21 & 512) != 0) {
				var14.recolourStartCycle = Client.cycle + var1.readUnsignedByteS();
				var14.recolourEndCycle = Client.cycle + var1.readUnsignedShort();
				var14.recolourHue = var1.readByte();
				var14.recolourSaturation = var1.method2431();
				var14.recolourLuminance = var1.method2404();
				var14.recolourAmount = (byte) var1.readUnsignedByteA();
			}

			if ((var21 & 1) != 0) {
				var14.spotAnimation = var1.readUnsignedByteS();
				var6 = var1.readInt();
				var14.spotAnimHeight = var6 >> 16;
				var14.spotAnimationStartCycle = (var6 & '\uffff') + Client.cycle;
				var14.spotAnimationFrame = 0;
				var14.spotAnimFrameCycle = 0;
				if (var14.spotAnimationStartCycle > Client.cycle) {
					var14.spotAnimationFrame = -1;
				}

				if (var14.spotAnimation == 65535) {
					var14.spotAnimation = -1;
				}
			}

			if ((var21 & 8192) != 0) {
				var6 = var1.readUnsignedByteA();
				if ((var6 & 1) == 1) {
					var14.method574();
				} else {
					var15 = null;
					if ((var6 & 2) == 2) {
						var8 = var1.readUnsignedByteA();
						var15 = new int[var8];

						for (var9 = 0; var9 < var8; ++var9) {
							var10 = var1.readUnsignedShortLEA();
							var10 = var10 == 65535 ? -1 : var10;
							var15[var9] = var10;
						}
					}

					var16 = null;
					if ((var6 & 4) == 4) {
						var9 = 0;
						if (var14.definition.recolorTo != null) {
							var9 = var14.definition.recolorTo.length;
						}

						var16 = new short[var9];

						for (var10 = 0; var10 < var9; ++var10) {
							var16[var10] = (short) var1.readUnsignedShortLE();
						}
					}

					var17 = null;
					if ((var6 & 8) == 8) {
						var10 = 0;
						if (var14.definition.retextureTo != null) {
							var10 = var14.definition.retextureTo.length;
						}

						var17 = new short[var10];

						for (var11 = 0; var11 < var10; ++var11) {
							var17[var11] = (short) var1.readUnsignedShortLE();
						}
					}

					var18 = (long) (++NPC.field1054 - 1);
					var14.method566(new NewShit(var18, var15, var16, var17));
				}
			}

			if ((var21 & 4) != 0) {
				var14.definition = class137.getNpcDefinition(var1.readUnsignedByteS());
				WorldMapID.method1457(var14);
				var14.method567();
			}
		}

		for (var2 = 0; var2 < Client.field502; ++var2) {
			var3 = Client.field503[var2];
			if (Client.npcs[var3].npcCycle != Client.cycle) {
				Client.npcs[var3].definition = null;
				Client.npcs[var3] = null;
			}
		}

		if (var1.offset != Client.packetWriter.serverPacketLength) {
			throw new RuntimeException(var1.offset + "," + Client.packetWriter.serverPacketLength);
		} else {
			for (var2 = 0; var2 < Client.npcCount; ++var2) {
				if (Client.npcs[Client.npcIndices[var2]] == null) {
					throw new RuntimeException(var2 + "," + Client.npcCount);
				}
			}

		}
	}
}
