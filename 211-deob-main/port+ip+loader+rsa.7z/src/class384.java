public class class384 {

	public static short[] field3658;
}
