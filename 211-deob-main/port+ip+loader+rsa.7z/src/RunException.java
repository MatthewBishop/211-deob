import java.applet.Applet;

public class RunException extends RuntimeException {

	public static Applet RunException_applet;

	public static String localPlayerName;

	public static int RunException_revision;

	public static int field4126;

	public static int field4130;

	String field4131;

	Throwable throwable;
}
