public interface class2 {
}
