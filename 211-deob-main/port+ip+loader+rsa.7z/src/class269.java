public interface class269 {

	void method1506(Object var1);
}
