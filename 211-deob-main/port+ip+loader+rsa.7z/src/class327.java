public class class327 {

	public static boolean method1788(int var0) {
		return var0 >= WorldMapDecorationType.field3049.id && var0 <= WorldMapDecorationType.field3050.id;
	}
}
