public class class275 {

	static SpritePixels rightTitleSprite;

	static void queueSoundEffect(int var0, int var1, int var2) {
		if (PacketWriter.clientPreferences.getCurrentSoundEffectsVolume() != 0 && var1 != 0
				&& Client.soundEffectCount < 50) {
			Client.soundEffectIds[Client.soundEffectCount] = var0;
			Client.queuedSoundEffectLoops[Client.soundEffectCount] = var1;
			Client.queuedSoundEffectDelays[Client.soundEffectCount] = var2;
			Client.soundEffects[Client.soundEffectCount] = null;
			Client.soundLocations[Client.soundEffectCount] = 0;
			++Client.soundEffectCount;
		}

	}

	static final void method1525(int var0, int var1, int var2) {
		if (ClanSettings.cameraX < var0) {
			ClanSettings.cameraX = (var0 - ClanSettings.cameraX) * UserComparator7.cameraMoveToAcceleration / 1000
					+ ClanSettings.cameraX + ModeWhere.cameraMoveToSpeed;
			if (ClanSettings.cameraX > var0) {
				ClanSettings.cameraX = var0;
			}
		}

		if (ClanSettings.cameraX > var0) {
			ClanSettings.cameraX -= (ClanSettings.cameraX - var0) * UserComparator7.cameraMoveToAcceleration / 1000
					+ ModeWhere.cameraMoveToSpeed;
			if (ClanSettings.cameraX < var0) {
				ClanSettings.cameraX = var0;
			}
		}

		if (UserComparator10.cameraY < var1) {
			UserComparator10.cameraY = (var1 - UserComparator10.cameraY) * UserComparator7.cameraMoveToAcceleration
					/ 1000 + UserComparator10.cameraY + ModeWhere.cameraMoveToSpeed;
			if (UserComparator10.cameraY > var1) {
				UserComparator10.cameraY = var1;
			}
		}

		if (UserComparator10.cameraY > var1) {
			UserComparator10.cameraY -= (UserComparator10.cameraY - var1) * UserComparator7.cameraMoveToAcceleration
					/ 1000 + ModeWhere.cameraMoveToSpeed;
			if (UserComparator10.cameraY < var1) {
				UserComparator10.cameraY = var1;
			}
		}

		if (class366.cameraZ < var2) {
			class366.cameraZ = (var2 - class366.cameraZ) * UserComparator7.cameraMoveToAcceleration / 1000
					+ class366.cameraZ + ModeWhere.cameraMoveToSpeed;
			if (class366.cameraZ > var2) {
				class366.cameraZ = var2;
			}
		}

		if (class366.cameraZ > var2) {
			class366.cameraZ -= (class366.cameraZ - var2) * UserComparator7.cameraMoveToAcceleration / 1000
					+ ModeWhere.cameraMoveToSpeed;
			if (class366.cameraZ < var2) {
				class366.cameraZ = var2;
			}
		}

	}

	static void method1524(int var0, int var1) {
		int var2 = class19.fontBold12.stringWidth("Choose Option");

		int var3;
		int var4;
		for (var3 = 0; var3 < Client.menuOptionsCount; ++var3) {
			var4 = class19.fontBold12.stringWidth(TriBool.method2128(var3));
			if (var4 > var2) {
				var2 = var4;
			}
		}

		var2 += 8;
		var3 = Client.menuOptionsCount * 15 + 22;
		var4 = var0 - var2 / 2;
		if (var4 + var2 > GameEngine.canvasWidth) {
			var4 = GameEngine.canvasWidth - var2;
		}

		if (var4 < 0) {
			var4 = 0;
		}

		int var5 = var1;
		if (var1 + var3 > class127.canvasHeight) {
			var5 = class127.canvasHeight - var3;
		}

		if (var5 < 0) {
			var5 = 0;
		}

		class130.menuX = var4;
		ModeWhere.menuY = var5;
		class7.menuWidth = var2;
		PlayerType.menuHeight = Client.menuOptionsCount * 15 + 22;
	}
}
