public class class419 {

	static int field3793;

	static Archive archive18;

	float[] field3795;

	int field3792;

	class419(float[] var1, int var2) {
		this.field3795 = var1;
		this.field3792 = var2;
	}
}
