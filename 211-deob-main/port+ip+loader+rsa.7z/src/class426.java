public interface class426 extends class425 {
}
