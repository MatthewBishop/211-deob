public class LongNode extends Node {

	public long longValue;

	public LongNode(long var1) {
		this.longValue = var1;
	}
}
