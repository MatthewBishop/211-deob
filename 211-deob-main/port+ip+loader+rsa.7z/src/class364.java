import java.awt.Image;

public final class class364 {

	static Image field3574;
}
