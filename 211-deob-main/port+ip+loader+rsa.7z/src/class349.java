public interface class349 {

	int rsOrdinal();
}
