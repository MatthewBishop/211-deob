public class ObjectNode extends Node {

	public final Object obj;

	public ObjectNode(Object var1) {
		this.obj = var1;
	}
}
