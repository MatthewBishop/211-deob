public enum VerticalAlignment implements class349 {

	field1598(1, 0),

	VerticalAlignment_centered(2, 1),

	field1600(0, 2);

	static int field1595;

	static String field1594;

	public final int value;

	final int id;

	VerticalAlignment(int var3, int var4) {
		this.value = var3;
		this.id = var4;
	}

	public int rsOrdinal() {
		return this.id;
	}
}
