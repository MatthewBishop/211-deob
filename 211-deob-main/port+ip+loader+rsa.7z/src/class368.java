public final class class368 {

	final Object field3581;

	int field3580;

	class368(Object var1, int var2) {
		this.field3581 = var1;
		this.field3580 = var2;
	}
}
