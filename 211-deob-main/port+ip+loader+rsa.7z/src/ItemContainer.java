public class ItemContainer extends Node {

	static NodeHashTable itemContainers = new NodeHashTable(32);

	int[] ids = new int[] { -1 };

	int[] quantities = new int[] { 0 };

	static class123 method455(int var0) {
		class123 var1 = (class123) class4.findEnumerated(UrlRequester.method628(), var0);
		if (var1 == null) {
			var1 = class123.field1193;
		}

		return var1;
	}
}
