public enum class330 implements class349 {

	field3403(-1),

	field3407(0),

	field3404(1),

	field3405(2);

	final int field3406;

	class330(int var3) {
		this.field3406 = var3;
	}

	public int rsOrdinal() {
		return this.field3406;
	}
}
