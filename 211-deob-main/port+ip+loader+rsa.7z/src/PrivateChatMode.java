public class PrivateChatMode {

	static final PrivateChatMode field4119 = new PrivateChatMode(0);

	public static final PrivateChatMode field4117 = new PrivateChatMode(1);

	static final PrivateChatMode field4118 = new PrivateChatMode(2);

	public final int id;

	PrivateChatMode(int var1) {
		this.id = var1;
	}
}
