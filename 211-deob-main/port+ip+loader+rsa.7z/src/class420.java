public enum class420 implements class349 {

	field3798(0, 1),

	field3797(3, 2),

	field3796(1, 3),

	field3799(2, 10);

	final int field3800;

	final int field3801;

	class420(int var3, int var4) {
		this.field3800 = var3;
		this.field3801 = var4;
	}

	public int rsOrdinal() {
		return this.field3801;
	}
}
