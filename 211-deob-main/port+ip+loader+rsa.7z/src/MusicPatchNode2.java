public class MusicPatchNode2 {

	static int field2701;

	byte[] field2699;

	byte[] field2697;

	int field2692;

	int field2693;

	int field2694;

	int field2698;

	int field2695;

	int field2700;

	int field2696;
}
