public interface class119 {
}
