import java.applet.Applet;

public class class26 {

	public static void method96(Applet var0, String var1) throws Throwable {
		// JSObject.getWindow(var0).eval(var1);
	}
}
