public class class498 {

	public static AbstractArchive HitSplatDefinition_archive;
}
