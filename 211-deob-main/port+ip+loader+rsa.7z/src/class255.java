public class class255 {

	static final class255 field2378 = new class255(0);

	static final class255 field2377 = new class255(1);

	final int value;

	class255(int var1) {
		this.value = var1;
	}
}
