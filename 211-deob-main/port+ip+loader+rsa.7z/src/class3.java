public interface class3 {

	Buffer vmethod12(Buffer var1);
}
