public abstract class PcmStreamMixerListener extends Node {

	int field303;

	abstract void remove2();

	abstract int update();
}
