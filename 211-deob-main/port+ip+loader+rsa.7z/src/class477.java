public interface class477 {

	void method2458(Buffer var1);
}
