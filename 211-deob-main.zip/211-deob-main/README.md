# OSRS 211 Deob

Run through _VanillaLauncher
Make sure deps in dep folder are on classpath
### Note: 
RS is 211 currently so the client loads javconfig from RS website. A copy of current javconfig is in root incase jagex updates.

This contains renaming and also removal of the math obfuscation. This will not work ingame when connecting to official jagex servers.
