public class class421 implements class426 {

	public final class451 field3802;

	class421(class452 var1) {
		this.field3802 = var1;
	}

	public class421(class422 var1) {
		this(new class452(var1));
	}

	public int method2194(int var1) {
		return this.field3802.vmethod8144(var1);
	}
}
