public interface class267 {
}
