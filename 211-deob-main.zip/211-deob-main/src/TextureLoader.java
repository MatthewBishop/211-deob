public interface TextureLoader {

	int[] getTexturePixels(int var1);

	int getAverageTextureRGB(int var1);

	boolean vmethod4645(int var1);

	boolean isLowDetail(int var1);
}
