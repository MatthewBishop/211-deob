public class class305 {

	static LoginScreenAnimation field2809;

	public class307 field2802 = new class307();

	class302 field2803 = new class302();

	class27 field2804 = new class27();

	public Object[] field2807;

	public Object[] field2806;

	public Object[] field2805;

	public Object[] field2808;
}
