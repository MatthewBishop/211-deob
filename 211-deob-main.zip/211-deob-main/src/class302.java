public class class302 {

	static int Interpreter_intStackSize;

	public int field2794;

	public int field2797;

	public int field2795;

	static char method1628(char var0) {
		return var0 != 181 && var0 != 402 ? Character.toTitleCase(var0) : var0;
	}
}
