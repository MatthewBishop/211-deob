public class Strings {

	public static String field3123 = "Please visit the support page for assistance.";

	public static String field3185 = "";

	public static String field3360 = "Page has opened in a new window.";

	public static String field3361 = "(Please check your popup blocker.)";
}
