public class class365 {

	static void method1926(int var0) {
		class416.field3769 = var0;
		class416.field3770 = new class416[var0];
		class388.field3666 = 0;
	}
}
