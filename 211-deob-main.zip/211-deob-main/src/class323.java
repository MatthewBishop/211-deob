public class class323 {

	static final class323 field3057 = new class323(51, 27, 800, 0, 16, 16);

	static final class323 field3056 = new class323(25, 28, 800, 656, 40, 40);

	static int[][] field3055;

	static boolean isLargePlayerInfo;

	static byte[][] regionMapArchives;

	final int field3060;

	final int field3058;

	class323(int var1, int var2, int var3, int var4, int var5, int var6) {
		this.field3060 = var5;
		this.field3058 = var6;
	}
}
