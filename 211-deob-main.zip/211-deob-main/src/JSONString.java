public interface JSONString {

	String toJSONString();
}
