public class class389 {

	public static final class389 field3670 = new class389(0);

	static final class389 field3669 = new class389(1);

	final int field3668;

	class389(int var1) {
		this.field3668 = var1;
	}
}
