public abstract class AbstractSound extends Node {

	int position;
}
