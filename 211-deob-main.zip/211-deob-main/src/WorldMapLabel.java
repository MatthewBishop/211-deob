public class WorldMapLabel {

	public static Widget[][] Widget_interfaceComponents;

	static int selectedItemWidget;

	String text;

	int width;

	int height;

	WorldMapLabelSize size;

	WorldMapLabel(String var1, int var2, int var3, WorldMapLabelSize var4) {
		this.text = var1;
		this.width = var2;
		this.height = var3;
		this.size = var4;
	}
}
