public enum FillMode implements class349 {

	SOLID(0, 0),

	field4072(1, 1),

	field4073(2, 2);

	public final int field4071;

	final int field4075;

	FillMode(int var3, int var4) {
		this.field4071 = var3;
		this.field4075 = var4;
	}

	public int rsOrdinal() {
		return this.field4075;
	}
}
