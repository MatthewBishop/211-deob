public class class367 extends RuntimeException {

	static SpritePixels[] headIconPrayerSprites;

	public class367(String var1, Object[] var2) {
		super(String.format(var1, var2));
	}
}
