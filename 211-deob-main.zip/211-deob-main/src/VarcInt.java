public class VarcInt extends DualNode {

	public static AbstractArchive VarcInt_archive;

	public static EvictingDualNodeHashTable VarcInt_cached = new EvictingDualNodeHashTable(64);

	static String field1501;

	public boolean persist = false;

	public void method930(Buffer var1) {
		while (true) {
			int var2 = var1.readUnsignedByte();
			if (var2 == 0) {
				return;
			}

			this.method931(var1, var2);
		}
	}

	void method931(Buffer var1, int var2) {
		if (var2 == 2) {
			this.persist = true;
		}

	}

	public static IndexedSprite SpriteBuffer_getIndexedSpriteByName(AbstractArchive var0, String var1, String var2) {
		int var3 = var0.getGroupId(var1);
		int var4 = var0.getFileId(var3, var2);
		IndexedSprite var5;
		if (!Buffer.method2444(var0, var3, var4)) {
			var5 = null;
		} else {
			IndexedSprite var7 = new IndexedSprite();
			var7.width = class488.SpriteBuffer_spriteWidth;
			var7.height = class488.SpriteBuffer_spriteHeight;
			var7.xOffset = class488.SpriteBuffer_xOffsets[0];
			var7.yOffset = ApproximateRouteStrategy.SpriteBuffer_yOffsets[0];
			var7.subWidth = FriendsList.SpriteBuffer_spriteWidths[0];
			var7.subHeight = class132.SpriteBuffer_spriteHeights[0];
			var7.palette = class100.SpriteBuffer_spritePalette;
			var7.pixels = class140.SpriteBuffer_pixels[0];
			class100.method595();
			var5 = var7;
		}

		return var5;
	}
}
