public class JagexCache {

	public static int idxCount;

	public static BufferedFile JagexCache_randomDat = null;

	public static BufferedFile JagexCache_dat2File = null;

	public static BufferedFile JagexCache_idx255File = null;
}
