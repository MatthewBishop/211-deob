public interface class278 {
}
