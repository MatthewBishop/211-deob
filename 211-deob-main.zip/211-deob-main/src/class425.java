public interface class425 {
}
