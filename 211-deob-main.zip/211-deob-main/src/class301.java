public interface class301 {

	void vmethod5708();
}
