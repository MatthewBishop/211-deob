public interface class29 {

	boolean vmethod3949(int var1);

	boolean vmethod3989(int var1);

	boolean vmethod3951(char var1);

	boolean vmethod3953(boolean var1);
}
