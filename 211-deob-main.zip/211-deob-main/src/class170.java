public interface class170 {

	int useRotation();
}
