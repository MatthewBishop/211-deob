public interface class50 {

    PcmPlayer player();
}
