public class class423 extends class424 {

    public static boolean musicTrackBoolean;

    public class423(int var1) {
        super(var1);
    }

    void vmethod7769(Buffer var1, int var2) {
    }
}
