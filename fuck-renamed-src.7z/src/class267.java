public interface class267 {
}
