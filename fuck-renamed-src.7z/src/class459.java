public interface class459 {

    void vmethod8274(Object var1, Buffer var2);

    Object vmethod8273(Buffer var1);
}
