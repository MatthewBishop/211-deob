import javax.imageio.ImageIO;

public class class30 {
    static {
        ImageIO.setUseCache(false);
    }

    public static int method117(CharSequence var0, int var1) {
        return GrandExchangeOfferUnitPriceComparator.method1864(var0, var1, true);
    }
}
