import java.io.UnsupportedEncodingException;

public interface class428 {

    class427 vmethod2213();

    byte[] vmethod7797() throws UnsupportedEncodingException;
}
