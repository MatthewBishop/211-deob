import java.net.MalformedURLException;
import java.net.URL;

public class class194 extends DualNode {
    static {
        new EvictingDualNodeHashTable(64);
    }

    public static ObjTypeCustomisation method982(int var0, Buffer var1) {
        int var2 = var1.readUnsignedByte();
        boolean var3 = (var2 & 1) != 0;
        boolean var4 = (var2 & 2) != 0;
        ObjTypeCustomisation var5 = new ObjTypeCustomisation(var0);
        int var6;
        int[] var7;
        boolean var8;
        int var9;
        short var10;
        if (var3) {
            var6 = var1.readUnsignedByte();
            var7 = new int[] { var6 & 15, var6 >> 4 & 15 };
            var8 = var5.recol != null && var7.length == var5.recol.length;

            for (var9 = 0; var9 < 2; ++var9) {
                if (var7[var9] != 15) {
                    var10 = (short) var1.readUnsignedShort();
                    if (var8) {
                        var5.recol[var7[var9]] = var10;
                    }
                }
            }
        }

        if (var4) {
            var6 = var1.readUnsignedByte();
            var7 = new int[] { var6 & 15, var6 >> 4 & 15 };
            var8 = var5.retex != null && var7.length == var5.retex.length;

            for (var9 = 0; var9 < 2; ++var9) {
                if (var7[var9] != 15) {
                    var10 = (short) var1.readUnsignedShort();
                    if (var8) {
                        var5.retex[var7[var9]] = var10;
                    }
                }
            }
        }

        return var5;
    }

    static boolean method980(String var0) {
        if (var0 == null) {
            return false;
        } else {
            try {
                new URL(var0);
                return true;
            } catch (MalformedURLException var2) {
                return false;
            }
        }
    }

    static void method981(boolean var0) {
        Client.leftClickOpensMenu = var0;
    }
}
