public class class172 {

    static short[][][] Tiles_overlays;

    static int field1439;

    public static int[] ByteArrayPool_alternativeSizes;

    public UrlRequest field1440;

    public float[] field1437;
    // $FF: synthetic field

    final class166 this$0;

    class172(class166 var1) {
        this.this$0 = var1;
        this.field1437 = new float[4];
    }
}
