public class class320 {

    static void method1780() {
        ItemContainer.itemContainers = new NodeHashTable(32);
    }
}
