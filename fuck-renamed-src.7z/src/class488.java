public class class488 {

    public static int SpriteBuffer_spriteCount;

    public static int SpriteBuffer_spriteWidth;

    public static int SpriteBuffer_spriteHeight;

    public static int[] SpriteBuffer_xOffsets;
}
