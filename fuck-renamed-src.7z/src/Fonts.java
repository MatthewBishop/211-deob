import java.util.HashMap;

public class Fonts {

    AbstractArchive spritesArchive;

    AbstractArchive fontsArchive;

    HashMap map;

    public Fonts(AbstractArchive var1, AbstractArchive var2) {
        this.spritesArchive = var1;
        this.fontsArchive = var2;
        this.map = new HashMap();
    }

    public HashMap createMap(FontName[] var1) {
        HashMap var2 = new HashMap();
        FontName[] var3 = var1;

        for (int var4 = 0; var4 < var3.length; ++var4) {
            FontName var5 = var3[var4];
            if (this.map.containsKey(var5)) {
                var2.put(var5, this.map.get(var5));
            } else {
                Font var6 = ScriptFrame.method318(this.spritesArchive, this.fontsArchive, var5.name, "");
                if (var6 != null) {
                    this.map.put(var5, var6);
                    var2.put(var5, var6);
                }
            }
        }

        return var2;
    }
}
