public interface class278 {
}
