public interface class2 {
}
