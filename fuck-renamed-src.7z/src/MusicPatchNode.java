public class MusicPatchNode extends Node {

    static Archive field2782;

    static String field2783;

    int field2771;

    MusicPatchNode2 field2764;

    MusicPatch patch;

    RawSound rawSound;

    int field2765;

    int field2766;

    int field2767;

    int field2768;

    int field2769;

    int field2763;

    int field2774;

    int field2772;

    int field2773;

    int field2777;

    int field2775;

    int field2761;

    int field2776;

    int field2778;

    RawPcmStream stream;

    int field2780;

    int field2781;

    void method1620() {
        this.patch = null;
        this.rawSound = null;
        this.field2764 = null;
        this.stream = null;
    }
}
