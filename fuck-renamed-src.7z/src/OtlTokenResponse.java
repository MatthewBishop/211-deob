public interface OtlTokenResponse {

    boolean isSuccess();

    String getToken();
}
