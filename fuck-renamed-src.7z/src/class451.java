public interface class451 extends Iterable {

    int vmethod8144(int var1);

    void vmethod8143(int var1, Object var2);
}
