public class class469 {

    static final int field3999 = (int) (Math.pow(2.0D, 4.0D) - 1.0D);

    static final int field3998 = (int) (Math.pow(2.0D, 8.0D) - 1.0D);
}
