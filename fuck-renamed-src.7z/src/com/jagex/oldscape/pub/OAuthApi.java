package com.jagex.oldscape.pub;

public interface OAuthApi {
}
