public class class386 {

    static final class386 field3661 = new class386("Basic");

    static final class386 field3660 = new class386("Bearer");

    final String field3659;

    class386(String var1) {
        this.field3659 = var1;
    }

    String method2031() {
        return this.field3659;
    }
}
