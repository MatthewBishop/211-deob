public interface class119 {
}
