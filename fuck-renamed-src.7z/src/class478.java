public class class478 implements class349 {

    public static final class478 field4053 = new class478(3, 0);

    public static final class478 field4049 = new class478(1, 2);

    static final class478 field4050 = new class478(5, 5);

    static final class478 field4051 = new class478(2, 6);

    static final class478 field4052 = new class478(0, 7);

    static final class478 field4048 = new class478(4, 8);

    final int field4054;

    final int field4055;

    class478(int var1, int var2) {
        this.field4054 = var1;
        this.field4055 = var2;
    }

    public int rsOrdinal() {
        return this.field4055;
    }

    public boolean method2459() {
        return this == field4049;
    }
}
