public class IntegerNode extends Node {

    public int integer;

    public IntegerNode(int var1) {
        this.integer = var1;
    }
}
