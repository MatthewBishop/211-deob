public interface PlatformInfoProvider {

    PlatformInfo get();
}
