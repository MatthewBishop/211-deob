public abstract class class177 {

    static Clock clock;

    String field1461;
    // $FF: synthetic field

    final class166 this$0;

    class177(class166 var1, String var2) {
        this.this$0 = var1;
        this.field1461 = var2;
    }

    public abstract int vmethod3379();

    public String vmethod3380() {
        return null;
    }

    public int vmethod3378() {
        return -1;
    }

    public String method903() {
        return this.field1461;
    }

    public static void method905() {
        class290.midiPcmStream.clear();
        class290.musicPlayerStatus = 1;
        class6.musicTrackArchive = null;
    }
}
