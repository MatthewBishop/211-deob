public interface class425 {
}
