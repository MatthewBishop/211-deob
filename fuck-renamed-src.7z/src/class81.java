public class class81 {

    public static void method457(AbstractArchive var0) {
        EnumComposition.EnumDefinition_archive = var0;
    }

    static char method456(char var0) {
        if (var0 == 198) {
            return 'E';
        } else if (var0 == 230) {
            return 'e';
        } else if (var0 == 223) {
            return 's';
        } else if (var0 == 338) {
            return 'E';
        } else {
            return (char) (var0 == 339 ? 'e' : '\u0000');
        }
    }
}
