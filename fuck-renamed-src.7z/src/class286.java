public final class class286 {

    static long field2687;

    static long field2688;

    static Archive archive15;
}
