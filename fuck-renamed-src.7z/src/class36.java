public class class36 {

    static Language clientLanguage;

    static MouseRecorder mouseRecorder;

    public static void method169() {
        ByteArrayPool.field3635.clear();
        ByteArrayPool.field3635.add(100);
        ByteArrayPool.field3635.add(5000);
        ByteArrayPool.field3635.add(10000);
        ByteArrayPool.field3635.add(30000);
    }
}
