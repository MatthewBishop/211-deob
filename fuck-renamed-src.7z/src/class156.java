public class class156 {

    long field1384;

    long field1382 = -1L;

    IterableNodeDeque field1383 = new IterableNodeDeque();

    public class156(Buffer var1) {
        this.method833(var1);
    }

    void method833(Buffer var1) {
        this.field1384 = var1.readLong();
        this.field1382 = var1.readLong();

        for (int var2 = var1.readUnsignedByte(); var2 != 0; var2 = var1.readUnsignedByte()) {
            Object var3;
            if (var2 == 1) {
                var3 = new class151(this);
            } else if (var2 == 4) {
                var3 = new class162(this);
            } else if (var2 == 3) {
                var3 = new class147(this);
            } else if (var2 == 2) {
                var3 = new class145(this);
            } else {
                if (var2 != 5) {
                    throw new RuntimeException("");
                }

                var3 = new class152(this);
            }

            ((class155) var3).vmethod3238(var1);
            this.field1383.addFirst((Node) var3);
        }

    }

    public void method832(ClanChannel var1) {
        if (var1.key == this.field1384 && this.field1382 == var1.field1394) {
            for (class155 var2 = (class155) this.field1383.last(); var2 != null; var2 = (class155) this.field1383
                    .previous()) {
                var2.vmethod3239(var1);
            }

            ++var1.field1394;
        } else {
            throw new RuntimeException("");
        }
    }

    static void sortWorlds(World[] var0, int var1, int var2, int[] var3, int[] var4) {
        if (var1 < var2) {
            int var5 = var1 - 1;
            int var6 = var2 + 1;
            int var7 = (var2 + var1) / 2;
            World var8 = var0[var7];
            var0[var7] = var0[var1];
            var0[var1] = var8;

            while (var5 < var6) {
                boolean var9 = true;

                int var10;
                int var11;
                int var12;
                do {
                    --var6;

                    for (var10 = 0; var10 < 4; ++var10) {
                        if (var3[var10] == 2) {
                            var11 = var0[var6].index;
                            var12 = var8.index;
                        } else if (var3[var10] == 1) {
                            var11 = var0[var6].population;
                            var12 = var8.population;
                            if (var11 == -1 && var4[var10] == 1) {
                                var11 = 2001;
                            }

                            if (var12 == -1 && var4[var10] == 1) {
                                var12 = 2001;
                            }
                        } else if (var3[var10] == 3) {
                            var11 = var0[var6].isMembersOnly() ? 1 : 0;
                            var12 = var8.isMembersOnly() ? 1 : 0;
                        } else {
                            var11 = var0[var6].id;
                            var12 = var8.id;
                        }

                        if (var12 != var11) {
                            if ((var4[var10] != 1 || var11 <= var12) && (var4[var10] != 0 || var11 >= var12)) {
                                var9 = false;
                            }
                            break;
                        }

                        if (var10 == 3) {
                            var9 = false;
                        }
                    }
                } while (var9);

                var9 = true;

                do {
                    ++var5;

                    for (var10 = 0; var10 < 4; ++var10) {
                        if (var3[var10] == 2) {
                            var11 = var0[var5].index;
                            var12 = var8.index;
                        } else if (var3[var10] == 1) {
                            var11 = var0[var5].population;
                            var12 = var8.population;
                            if (var11 == -1 && var4[var10] == 1) {
                                var11 = 2001;
                            }

                            if (var12 == -1 && var4[var10] == 1) {
                                var12 = 2001;
                            }
                        } else if (var3[var10] == 3) {
                            var11 = var0[var5].isMembersOnly() ? 1 : 0;
                            var12 = var8.isMembersOnly() ? 1 : 0;
                        } else {
                            var11 = var0[var5].id;
                            var12 = var8.id;
                        }

                        if (var11 != var12) {
                            if ((var4[var10] != 1 || var11 >= var12) && (var4[var10] != 0 || var11 <= var12)) {
                                var9 = false;
                            }
                            break;
                        }

                        if (var10 == 3) {
                            var9 = false;
                        }
                    }
                } while (var9);

                if (var5 < var6) {
                    World var13 = var0[var5];
                    var0[var5] = var0[var6];
                    var0[var6] = var13;
                }
            }

            sortWorlds(var0, var1, var6, var3, var4);
            sortWorlds(var0, var6 + 1, var2, var3, var4);
        }

    }
}
