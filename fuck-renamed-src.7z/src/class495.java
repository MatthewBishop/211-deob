public abstract class class495 {

    static final String[] field4122 = new String[32];

    static {
        field4122[0] = "MEMBERS";
        field4122[1] = "QUICKCHAT";
        field4122[2] = "PVPWORLD";
        field4122[3] = "LOOTSHARE";
        field4122[4] = "DEDICATEDACTIVITY";
        field4122[5] = "BOUNTYWORLD";
        field4122[6] = "PVPARENA";
        field4122[7] = "HIGHLEVELONLY_1500";
        field4122[8] = "SPEEDRUN";
        field4122[9] = "EXISTINGPLAYERSONLY";
        field4122[10] = "EXTRAHARDWILDERNESS";
        field4122[11] = "DUNGEONEERING";
        field4122[12] = "INSTANCE_SHARD";
        field4122[13] = "RENTABLE";
        field4122[14] = "LASTMANSTANDING";
        field4122[15] = "NEW_PLAYERS";
        field4122[16] = "BETA_WORLD";
        field4122[17] = "STAFF_IP_ONLY";
        field4122[18] = "HIGHLEVELONLY_2000";
        field4122[19] = "HIGHLEVELONLY_2400";
        field4122[20] = "VIPS_ONLY";
        field4122[21] = "HIDDEN_WORLD";
        field4122[22] = "LEGACY_ONLY";
        field4122[23] = "EOC_ONLY";
        field4122[24] = "BEHIND_PROXY";
        field4122[25] = "NOSAVE_MODE";
        field4122[26] = "TOURNAMENT_WORLD";
        field4122[27] = "FRESHSTART";
        field4122[28] = "HIGHLEVELONLY_1750";
        field4122[29] = "DEADMAN";
        field4122[30] = "SEASONAL";
        field4122[31] = "EXTERNAL_PARTNER_ONLY";
    }
}
