public interface class481 {

    Object vmethod8697(int var1);
}
